# Messages Web Client

Build your messages web client here. You can use whatever client-side framework you want, but use something you are familiar with so that you don't spend too much time working on the client. Since this is a servers-side development course, we won't grade your client implementation nor UX, so feel free to keep it simple. You can always go back and make this fancy for a portfolio piece after the course is over.
