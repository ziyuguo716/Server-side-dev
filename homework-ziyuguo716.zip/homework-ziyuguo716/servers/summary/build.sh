docker build -t gzy123/summary .
docker push gzy123/summary

go clean