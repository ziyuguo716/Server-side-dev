# docker rm -f info441mysql

docker build -t gzy123/db .

# docker run -d \
# -p 3307:3307 \
# --name info441mysql \
# -e MYSQL_ROOT_PASSWORD=mypassword \
# -e MYSQL_DATABASE=mydb \
# mysql


