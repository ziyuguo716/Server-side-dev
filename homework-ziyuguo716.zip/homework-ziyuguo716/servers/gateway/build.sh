GOOS=linux go build

docker build -t gzy123/gateway .

go clean

