docker build -t gzy123/messaging .
docker push gzy123/messaging

go clean